  <link rel="stylesheet" href="public/css/jquery.dataTables.min.css">

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script src="public/js/jquery.dataTables.min.js"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cretesol\resources\views/home.blade.php ENDPATH**/ ?>