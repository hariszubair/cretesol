@include('layouts.dashboard.header')
@include('layouts.dashboard.navbar')
@include('layouts.dashboard.sidebar')
      @yield('content')
@include('layouts.dashboard.footer')

      @yield('footer')


