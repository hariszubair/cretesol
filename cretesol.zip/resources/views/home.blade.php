@extends('layouts.dashboard.master')
  <link rel="stylesheet" href="public/css/jquery.dataTables.min.css">

@section('content')

@endsection

@section('footer')
<script src="public/js/jquery.dataTables.min.js"></script>


@endsection